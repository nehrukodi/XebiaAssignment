package org.Xebia.Assignment

import org.apache.spark.{SparkConf, SparkContext}


object CheckPoint1 extends App{

  val conf = new SparkConf().setMaster("local").setAppName("CheckPoint1")
  val sc = new SparkContext(conf)

  val textFileRDD = sc.textFile("src/main/resources/input_files/Checkpoint1.txt")

  val ipRDD = textFileRDD.filter(rec => rec.split(" ")(0) != "")
    .map(rec => (rec.split(" ")(0),1)).reduceByKey(_ + _)



  val resultRDD = ipRDD.sortBy(_._2,false).take(5)

  //List top 5 ip addresses for more hits
  resultRDD.foreach(println)


}
