package org.Xebia.Assignment


import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.expressions.Window
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.functions._

/**
  * Created by hduser on 12/24/18.
  */
object CheckPoint2 extends App {

  val conf = new SparkConf().setAppName("checkPoint2").setMaster("local")
  val sc =  new SparkContext(conf)
  val ss = new HiveContext(sc)

  val opt = Map("header" -> "true","inferSchema" -> "true")

  val customerDF = ss.read.format("com.databricks.spark.csv")
    .options(opt).load("src/main/resources/input_files/customers.csv")

  val salesDF = ss.read.format("com.databricks.spark.csv")
    .options(opt).load("src/main/resources/input_files/sales.csv")

  //customerDF.printSchema()
  //salesDF.printSchema()
  val joinedDF = salesDF.join(broadcast(customerDF),"customer_id")
      .select("customer_id","transaction_id","product_id","sell_price","location")


  //a) Find locations in which sale of each product is max

  joinedDF.groupBy("location","product_id").agg(count("product_id"))
      .withColumnRenamed("count(product_id)", "count")
      .withColumn("rn",row_number().over(Window.partitionBy("product_id").orderBy(desc("count"))))
      .where("rn=1")
      .drop("rn")
      .show

  //b) Find customer who has purchased max number of items
  joinedDF.groupBy("customer_id").agg(count("product_id"))
    .withColumnRenamed("count(product_id)", "count")
      .orderBy(desc("count"))
      .limit(1)
      .show

  //c) Find customer who has spent max money

  joinedDF.groupBy("customer_id").agg(sum("sell_price"))
    .withColumnRenamed("sum(sell_price)", "saleAmount")
    .orderBy(desc("saleAmount"))
    .limit(1)
    .show

  //d) Find product which has min sale in terms of money
  joinedDF.groupBy("product_id").agg(sum("sell_price"))
    .withColumnRenamed("sum(sell_price)", "saleAmount")
    .orderBy("saleAmount")
    .limit(1)
    .show

  //e) Find product which has min sale in terms of number of unit sold

  joinedDF.groupBy("product_id").count()
    .orderBy("count")
    .limit(1)
    .show



}
