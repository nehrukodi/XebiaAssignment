package org.Xebia.Assignment
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.expressions.Window
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.functions._
import org.joda.time.Days;
import org.joda.time.LocalDate;

/**
  * Created by hduser on 12/24/18.
  */
object CheckPoint4 extends App {

  def dtDiff(x: String, y: String) =
  {
    val date1 = LocalDate.parse(x);
    val date2 = LocalDate.parse(y);

    Days.daysBetween(date2,date1).getDays()
  }


  val conf = new SparkConf().setAppName("checkPoint4").setMaster("local")
  val sc = new SparkContext(conf)
  val ss = new HiveContext(sc)

  val opt = Map("header" -> "true", "inferSchema" -> "true", "delimiter" -> "|")

  val rawDataDF = ss.read.format("com.databricks.spark.csv")
    .options(opt).load("src/main/resources/input_files/Checkpoint4.csv")

  import ss.implicits._

  //a) You need to parse the State and City into two different columns.

  rawDataDF.withColumn("splitdata", split(col("location"), "-"))
    .select($"id", $"end_date", $"start_date",
      col("splitdata").getItem(0).as("state"),
      col("splitdata").getItem(1).as("city")).show

  //b) You need to get the number of days in between the start and end dates. Perform it in two ways.

  rawDataDF.withColumn("diff_in_Days", datediff(col("end_date"), col("start_date")))
    .show

  rawDataDF.registerTempTable("test")

  ss.udf.register("dtDiff",
    dtDiff _ )

  val testDF = ss.sql("Select *, dtDiff(to_date(end_date),to_date(start_date)) as diff_in_Days from test")
  testDF.show



}
